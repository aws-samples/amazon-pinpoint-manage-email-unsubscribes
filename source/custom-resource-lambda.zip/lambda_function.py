import cfnresponse
import os
import logging
import traceback
import boto3
import json
import time

athena = boto3.client('athena')
sesv2 = boto3.client('sesv2')


def execute_named_queries(namedQueries):
    try:
        response = athena.batch_get_named_query(
            NamedQueryIds=namedQueries
        )

        for q in response['NamedQueries']:
            start_query_response = athena.start_query_execution(
                QueryString=q['QueryString'],
                QueryExecutionContext={
                  'Database': q['Database']
                },
                ResultConfiguration={
                  'OutputLocation': 's3://%s/temp/' % (os.environ.get('S3_DATA_BUCKET'))
                }
            )

            while True:
                time.sleep(2)

                get_query_response = athena.get_query_execution(
                    QueryExecutionId=start_query_response['QueryExecutionId']
                )

                if get_query_response['QueryExecution']['Status']['State'] == 'SUCCEEDED' or get_query_response['QueryExecution']['Status']['State'] == 'FAILED':
                    logging.debug('Query Result for: %s' % (q['Name']), get_query_response)
                    break
    except Exception as error:
        logging.error('execute_named_queries error: %s' % (error))
        logging.error('execute_named_queries trace: %s' % traceback.format_exc())
        raise

def lambda_handler(event, context):

    log_level = str(os.environ.get('LOG_LEVEL')).upper()
    if log_level not in [
                      'DEBUG', 'INFO',
                      'WARNING', 'ERROR',
                      'CRITICAL'
                  ]:
      log_level = 'DEBUG'
    logging.getLogger().setLevel(log_level)

    logging.debug(event)

    try:
        if event['ResourceProperties']['CustomResourceAction'] == 'SetupNamedQueries':
            execute_named_queries([os.environ.get('ALL_EVENT_TABLE')])
            execute_named_queries([os.environ.get('SEND_NQ'),
                os.environ.get('HARD_BOUNCE_NQ'),
                os.environ.get('SOFT_BOUNCE_NQ'),
                os.environ.get('COMPLAINT_NQ'),
                os.environ.get('DELIVERY_NQ'),
                os.environ.get('OPEN_NQ'),
                os.environ.get('CLICK_NQ'),
                os.environ.get('UNSUB_NQ'),
                os.environ.get('REJECT_NQ'),
                os.environ.get('CAMPAIGN_SEND_NQ'),
                os.environ.get('JOURNEY_SEND_NQ')])

            cfnresponse.send(event, context, cfnresponse.SUCCESS, {"success": True}, 'SetupNamedQueries')
        else:
            logging.error('Missing CustomResourceAction - no action to perform')
            cfnresponse.send(event, context, cfnresponse.FAILED, {"success": False, "error": "Missing CustomResourceAction"}, "error")

    except Exception as error:
        logging.error('lambda_handler error: %s' % (error))
        logging.error('lambda_handler trace: %s' % traceback.format_exc())
        cfnresponse.send(event, context, cfnresponse.FAILED, {"success": False, "error": "See Lambda Logs"}, "error")