import json
import boto3
import logging
import traceback
import datetime
import json
import os
import urllib.request, urllib.error, urllib.parse

client = boto3.client('athena')

def lambda_handler(event, context):
    log_level = str(os.environ.get('LOG_LEVEL')).upper()
    if log_level not in [
                        'DEBUG', 'INFO',
                        'WARNING', 'ERROR',
                        'CRITICAL'
                    ]:
      log_level = 'DEBUG'
    logging.getLogger().setLevel(log_level)

    logging.debug(event)

    try:
        for record in event['Records']:
            key = record['s3']['object']['key']
            parts = key.split('/')

            s3Bucket = 's3://' + record['s3']['bucket']['name']

            query = "ALTER TABLE all_events ADD IF NOT EXISTS PARTITION (ingest_timestamp='%s-%s-%s %s:00:00') LOCATION '%s/%s/%s/%s/%s'" % (parts[1], parts[2], parts[3], parts[4], s3Bucket + '/events', parts[1], parts[2], parts[3], parts[4])

            logging.debug(query)

            response = client.start_query_execution(
              QueryString=query,
              QueryExecutionContext={
                  'Database': os.environ.get('DATABASE_NAME')
              },
              ResultConfiguration={
                  'OutputLocation': s3Bucket + '/temp'
              }
            )

            logging.debug(response)

    except Exception as error:
        logging.error('lambda_handler error: %s' % (error))
        logging.error('lambda_handler trace: %s' % traceback.format_exc())
        result = {
            'statusCode': '500',
            'body':  {'message': 'error'}
        }
        return json.dumps(result)